// General leads CRUD bridge between the renderer and the SQLite layer.

import { ipcMain } from "electron";
import {
  getAllLeads,
  updateLeadStatus,
  getNoteForLead,
  saveNoteForLead,
} from "../../modules/leads/database/database";
import type { LeadStatus } from "../../modules/leads/types/job";

export function registerLeadsIpc(): void {
  ipcMain.handle("leads:getAll", () => {
    return getAllLeads();
  });

  ipcMain.handle("leads:updateStatus", (_event, id: number, status: LeadStatus) => {
    updateLeadStatus(id, status);
    return { ok: true };
  });

  ipcMain.handle("leads:getNote", (_event, leadId: number) => {
    const note = getNoteForLead(leadId);
    return { ok: true, note };
  });

  ipcMain.handle("leads:saveNote", (_event, leadId: number, text: string) => {
    const note = saveNoteForLead(leadId, text);
    return { ok: true, note };
  });
}
