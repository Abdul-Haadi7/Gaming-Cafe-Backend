// SQLite persistence for Module C, per SOW Section 5 ("Local data store:
// Embedded SQLite for scheduled posts, leads, SEO data, and settings").
// Runs in the main process only.
//
// Schema mirrors the team's Postgres/Supabase table design field-for-field
// (same column names) so nothing else in the app — types, IPC, UI — needs
// to change if the project moves between local SQLite and a hosted DB later.

import Database from "better-sqlite3";
import path from "node:path";
import { app } from "electron";
import type { Lead, LeadNote, LeadStatus } from "../types/job";

let db: Database.Database | null = null;

interface LeadRow {
  id: number;
  created_at: string;
  raw_job_id: number | null;
  source_id: number | null;
  external_job_id: string | null;
  company_name: string;
  company_domain: string | null;
  job_title: string;
  job_url: string;
  location: string | null;
  date_posted: string | null;
  description: string | null;
  industry: string | null;
  remote_only: number;
  employment_type: string | null;
  deduplication_key: string | null;
  status: LeadStatus;
  updated_at: string;
}

export function initDatabase(): void {
  const dbPath = path.join(app.getPath("userData"), "signal-desk.db");
  db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");

  db.exec(`
    CREATE TABLE IF NOT EXISTS leads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at TEXT NOT NULL,
      raw_job_id INTEGER,
      source_id INTEGER,
      external_job_id TEXT,
      company_name TEXT NOT NULL,
      company_domain TEXT,
      job_title TEXT NOT NULL,
      job_url TEXT NOT NULL,
      location TEXT,
      date_posted TEXT,
      description TEXT,
      industry TEXT,
      remote_only INTEGER NOT NULL DEFAULT 0,
      employment_type TEXT,
      deduplication_key TEXT UNIQUE,
      status TEXT NOT NULL DEFAULT 'New',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS lead_notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at TEXT NOT NULL,
      lead_id INTEGER NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
      note TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_lead_notes_leadId ON lead_notes(lead_id);
  `);
}

function getDb(): Database.Database {
  if (!db) throw new Error("Database not initialized — call initDatabase() first.");
  return db;
}

function rowToLead(row: LeadRow): Lead {
  return { ...row, remote_only: !!row.remote_only };
}

export function getAllLeads(): Lead[] {
  const rows = getDb().prepare("SELECT * FROM leads ORDER BY date_posted DESC").all() as LeadRow[];
  return rows.map(rowToLead);
}

export function updateLeadStatus(id: number, status: LeadStatus): void {
  getDb()
    .prepare("UPDATE leads SET status = ?, updated_at = ? WHERE id = ?")
    .run(status, new Date().toISOString(), id);
}

// Called by Person 1/2's pipeline once a posting has been normalized and
// de-duplicated. Inserts if new (by deduplication_key); otherwise a no-op,
// leaving any existing status/notes untouched.
export function upsertLead(lead: Omit<Lead, "created_at" | "updated_at" | "id"> & { id?: number }): void {
  const now = new Date().toISOString();
  getDb()
    .prepare(
      `INSERT INTO leads (created_at, raw_job_id, source_id, external_job_id, company_name, company_domain, job_title, job_url, location, date_posted, description, industry, remote_only, employment_type, deduplication_key, status, updated_at)
       VALUES (@created_at, @raw_job_id, @source_id, @external_job_id, @company_name, @company_domain, @job_title, @job_url, @location, @date_posted, @description, @industry, @remote_only, @employment_type, @deduplication_key, @status, @updated_at)
       ON CONFLICT(deduplication_key) DO NOTHING`
    )
    .run({
      ...lead,
      remote_only: lead.remote_only ? 1 : 0,
      created_at: now,
      updated_at: now,
    });
}

export function getNoteForLead(leadId: number): LeadNote | null {
  const row = getDb()
    .prepare("SELECT * FROM lead_notes WHERE lead_id = ? ORDER BY created_at DESC LIMIT 1")
    .get(leadId) as LeadNote | undefined;
  return row ?? null;
}

// Upsert-by-lead: updates the existing note if one exists for this lead,
// otherwise inserts a new row.
export function saveNoteForLead(leadId: number, text: string): LeadNote {
  const existing = getNoteForLead(leadId);
  const now = new Date().toISOString();

  if (existing) {
    getDb().prepare("UPDATE lead_notes SET note = ?, updated_at = ? WHERE id = ?").run(text, now, existing.id);
    return { ...existing, note: text, updated_at: now };
  }

  const info = getDb()
    .prepare("INSERT INTO lead_notes (created_at, lead_id, note, updated_at) VALUES (?, ?, ?, ?)")
    .run(now, leadId, text, now);
  return { id: Number(info.lastInsertRowid), created_at: now, lead_id: leadId, note: text, updated_at: now };
}

// Dev/demo convenience so the UI has something to show before Person 1's
// connector is wired up. Only inserts if the table is empty.
export function seedIfEmpty(seed: Array<Omit<Lead, "created_at" | "updated_at" | "id">>): void {
  const { count } = getDb().prepare("SELECT COUNT(*) as count FROM leads").get() as { count: number };
  if (count > 0) return;
  const insert = getDb().transaction((leads: typeof seed) => {
    for (const lead of leads) upsertLead(lead);
  });
  insert(seed);
}
