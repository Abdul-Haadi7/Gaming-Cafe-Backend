import { contextBridge, ipcRenderer } from "electron";
import type { Lead, LeadStatus, LeadNote } from "../modules/leads/types/job";

export interface ElectronAPI {
  ping: () => string;
  getLeads: () => Promise<Lead[]>;
  updateLeadStatus: (id: number, status: LeadStatus) => Promise<{ ok: boolean }>;
  getNote: (leadId: number) => Promise<{ ok: boolean; note: LeadNote | null }>;
  saveNote: (leadId: number, text: string) => Promise<{ ok: boolean; note: LeadNote }>;
  exportLeads: (
    leads: Lead[]
  ) => Promise<{ ok: boolean; canceled?: boolean; filePath?: string; error?: string }>;
  generateOutreach: (lead: Lead) => Promise<{ ok: boolean; text?: string; error?: string }>;
}

const api: ElectronAPI = {
  ping: () => "pong",
  getLeads: () => ipcRenderer.invoke("leads:getAll"),
  updateLeadStatus: (id, status) => ipcRenderer.invoke("leads:updateStatus", id, status),
  getNote: (leadId) => ipcRenderer.invoke("leads:getNote", leadId),
  saveNote: (leadId, text) => ipcRenderer.invoke("leads:saveNote", leadId, text),
  exportLeads: (leads) => ipcRenderer.invoke("leads:export", leads),
  generateOutreach: (lead) => ipcRenderer.invoke("leads:generateOutreach", lead),
};

contextBridge.exposeInMainWorld("electronAPI", api);
