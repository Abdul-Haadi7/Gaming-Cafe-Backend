// Drafts a cold-outreach email seeded from a lead's job posting, via the
// Anthropic API. Runs in the main process so the API key never reaches the
// sandboxed renderer.

import { ipcMain } from "electron";
import axios from "axios";
import type { Lead } from "../../modules/leads/types/job";

interface OutreachResult {
  ok: boolean;
  text?: string;
  error?: string;
}

function buildPrompt(lead: Lead): string {
  return `You are drafting a short, warm cold-outreach email from a sales rep at a company that sells an AI virtual receptionist product. It is addressed to a company that just posted this job opening, which signals they are hiring for the role and may be a good fit for an AI alternative:

Company: ${lead.company_name}
Job posting title: ${lead.job_title}
Location: ${lead.location ?? "unknown"}
Industry: ${lead.industry ?? "unknown"}
Posted: ${lead.date_posted ? lead.date_posted.slice(0, 10) : "unknown"}

Write a 3-4 sentence email. Open with "Hi ${lead.company_name}," on its own line. Reference the specific job posting naturally, briefly explain the AI receptionist angle, and end with a low-pressure call to action (like a 15-minute call). No subject line, no signature block, no placeholders in brackets. Plain text only.`;
}

export function registerOutreachIpc(): void {
  ipcMain.handle("leads:generateOutreach", async (_event, lead: Lead): Promise<OutreachResult> => {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return { ok: false, error: "No ANTHROPIC_API_KEY found. Add one to your .env file (see .env.example)." };
    }

    try {
      const response = await axios.post(
        "https://api.anthropic.com/v1/messages",
        {
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          messages: [{ role: "user", content: buildPrompt(lead) }],
        },
        {
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            "anthropic-version": "2023-06-01",
          },
        }
      );

      const content = response.data?.content as Array<{ text?: string }> | undefined;
      const text = (content ?? []).map((b) => b.text ?? "").join("\n").trim();
      if (!text) return { ok: false, error: "Empty response from the model." };
      return { ok: true, text };
    } catch (err) {
      if (axios.isAxiosError(err)) {
        const status = err.response?.status;
        const body = JSON.stringify(err.response?.data ?? {}).slice(0, 200);
        return { ok: false, error: `API error ${status ?? ""}: ${body}` };
      }
      return { ok: false, error: err instanceof Error ? err.message : String(err) };
    }
  });
}
