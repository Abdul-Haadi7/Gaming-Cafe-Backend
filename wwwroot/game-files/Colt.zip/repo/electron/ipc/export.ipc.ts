// Exports the currently filtered lead list to a CSV file via a native save
// dialog, with the exact column set/order requested:
// Company, Job Title, Location, Status, Date, URL

import { ipcMain, dialog, BrowserWindow } from "electron";
import fs from "node:fs";
import type { Lead } from "../../modules/leads/types/job";

interface ExportResult {
  ok: boolean;
  canceled?: boolean;
  filePath?: string;
  error?: string;
}

function toCsv(leads: Lead[]): string {
  const headers = ["Company", "Job Title", "Location", "Status", "Date", "URL"];
  const escape = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;

  const rows = leads.map((l) =>
    [
      escape(l.company_name),
      escape(l.job_title),
      escape(l.location ?? ""),
      escape(l.status),
      escape(l.date_posted ? l.date_posted.slice(0, 10) : ""),
      escape(l.job_url),
    ].join(",")
  );

  return [headers.join(","), ...rows].join("\n");
}

export function registerExportIpc(getWindow: () => BrowserWindow | null): void {
  ipcMain.handle("leads:export", async (_event, leads: Lead[]): Promise<ExportResult> => {
    const win = getWindow();
    const defaultName = `leads-export-${new Date().toISOString().slice(0, 10)}.csv`;

    const { canceled, filePath } = win
      ? await dialog.showSaveDialog(win, {
          defaultPath: defaultName,
          filters: [{ name: "CSV", extensions: ["csv"] }],
        })
      : await dialog.showSaveDialog({
          defaultPath: defaultName,
          filters: [{ name: "CSV", extensions: ["csv"] }],
        });
    if (canceled || !filePath) return { ok: false, canceled: true };

    try {
      fs.writeFileSync(filePath, toCsv(leads), "utf-8");
      return { ok: true, filePath };
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) };
    }
  });
}
