// General leads CRUD bridge between the renderer and Supabase.

import { ipcMain } from "electron";
import {
  getAllLeads,
  updateLeadStatus,
  getNoteForLead,
  saveNoteForLead,
} from "../../modules/leads/database/database";
import type { LeadStatus } from "../../modules/leads/types/job";

export function registerLeadsIpc(): void {
  ipcMain.handle("leads:getAll", async () => {
    return getAllLeads();
  });

  ipcMain.handle("leads:updateStatus", async (_event, id: number, status: LeadStatus) => {
    await updateLeadStatus(id, status);
    return { ok: true };
  });

  ipcMain.handle("leads:getNote", async (_event, leadId: number) => {
    const note = await getNoteForLead(leadId);
    return { ok: true, note };
  });

  ipcMain.handle("leads:saveNote", async (_event, leadId: number, text: string) => {
    const note = await saveNoteForLead(leadId, text);
    return { ok: true, note };
  });
}
