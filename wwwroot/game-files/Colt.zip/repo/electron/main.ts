import { app, BrowserWindow } from "electron";
import path from "node:path";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import { initSupabase } from "../modules/leads/database/database";
import { registerLeadsIpc } from "./ipc/leads.ipc";
import { registerExportIpc } from "./ipc/export.ipc";
import { registerOutreachIpc } from "./ipc/outreach.ipc";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Compiled main.js lives at dist-electron/electron/main.js, so the project
// root .env is two levels up.
dotenv.config({ path: path.join(__dirname, "..", "..", ".env") });

let mainWindow: BrowserWindow | null = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (app.isPackaged) {
    mainWindow.loadFile(path.join(__dirname, "..", "..", "dist", "index.html"));
  } else {
    mainWindow.loadURL("http://localhost:5173");
  }

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  initSupabase();

  registerLeadsIpc();
  registerExportIpc(() => mainWindow);
  registerOutreachIpc();

  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
