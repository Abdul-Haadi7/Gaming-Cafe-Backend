# Signal Desk — Module C (Lead Generation Engine)

Electron + React + TypeScript desktop app. This covers the Person 3 slice —
lead display, notes, CSV export, AI outreach — wired to the team's live
Supabase database.

## Fixes made to the original scaffold

A few things in the initial project skeleton didn't actually work; fixed
here so `npm run build` / `npm run dev` run clean:

- `tsconfig.node.json` only included `vite.config.ts`, so `build:electron`
  compiled nothing. It now includes `electron/**/*.ts` and `modules/**/*.ts`.
- `index.html` pointed at `/src/main.jsx`, which doesn't exist — the real
  entry file is `main.tsx`.
- `.gitignore` was wrapped in a markdown code fence (```gitignore ... ```),
  which isn't valid — cleaned up to a plain ignore file.
- Removed duplicate `vite.config.js` / `vite.config.d.ts` sitting alongside
  `vite.config.ts` (stale build artifacts that shouldn't have been committed).
- Swapped `better-sqlite3` for `@supabase/supabase-js`, since the team is
  using Supabase, not local SQLite — this also removes the native-module
  rebuild step (`electron-rebuild`) entirely, which is one less thing to
  break across teammates' machines.

## Architecture

- **`electron/main.ts`** — creates the window, initializes the Supabase
  client, registers IPC handlers.
- **`electron/preload.ts`** — the only bridge the sandboxed renderer can
  use (`contextIsolation: true`, `nodeIntegration: false`). Exposes
  `window.electronAPI`.
- **`electron/ipc/*.ipc.ts`** — one file per concern: `leads.ipc.ts` (CRUD),
  `export.ipc.ts` (CSV), `outreach.ipc.ts` (AI draft).
- **`modules/leads/database/database.ts`** — all Supabase queries live
  here. Nothing outside this file talks to Supabase directly.
- **`modules/leads/types/job.ts`** — the `Lead` / `LeadNote` types, matching
  the live schema field-for-field (snake_case, as Postgres returns it).
- **`src/`** — the renderer: `App.tsx`, `components/`, and a Zustand store
  (`store/useLeadsStore.ts`) holding leads, filters, sort, and view state.

The Supabase key and the Anthropic API key both live only in the main
process (`.env`, loaded via `dotenv`) — the renderer never sees either.

## What's implemented

- **Grid display**: leads render as a responsive 3-column grid of boxes
  (`src/components/LeadGrid.tsx` / `LeadBox.tsx`), each showing company,
  job title, location, remote badge, status badge, date posted, and a link
  to the posting.
- **Notes**: "Edit notes" opens a modal that fetches the existing note for
  that lead from `lead_notes` (if any), lets you edit it, and saves via
  upsert — insert if none existed, update if it did.
- **Sort**: by date posted, company, location, or status, with a direction
  toggle.
- **Filter**: by status and remote/on-site, plus free-text search across
  company/title/location. "Clear" resets all filters and sort.
- **CSV export**: exact columns requested — `Company,Job Title,Location,
  Status,Date,URL` — written via a native save dialog.
- **AI outreach**: "Generate outreach" calls the Anthropic API (server-side,
  via axios in the main process) seeded with the lead's company, title,
  location, and industry, and shows an editable draft.

## Setup

```bash
npm install
cp .env.example .env   # fill in SUPABASE_URL, SUPABASE_KEY, ANTHROPIC_API_KEY
```

Your Supabase `leads` and `lead_notes` tables should already match the
schema in `modules/leads/types/job.ts`.

## Run in development

```bash
npm run dev
```

Starts the Vite dev server, watches/compiles the Electron TS files, and
launches the Electron window pointed at `http://localhost:5173`.

## Build & package

```bash
npm run build   # tsc type-check + vite build (renderer) + tsc (electron)
npm run dist    # electron-builder — produces a Windows installer under release/
```

## Not in this pass (Person 1 / Person 2 scope)

- Populating `leads` from job-board connectors (Indeed, RemoteOK, etc.) and
  the LinkedIn partner API.
- Normalization, de-duplication, and saved searches.
- `modules/leads/services/{normalizer,deduplicator,filter,lead-engine}.ts`
  are left as empty stubs — untouched, since they're outside this scope.
