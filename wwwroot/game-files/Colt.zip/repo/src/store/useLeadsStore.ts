import { create } from "zustand";
import type { Lead, LeadStatus } from "../../modules/leads/types/job";

export type SortKey = "date_posted" | "company_name" | "location" | "status";
export type RemoteFilter = "all" | "remote" | "onsite";

interface LeadsState {
  leads: Lead[];
  loading: boolean;
  error: string;

  query: string;
  statusFilter: LeadStatus | "All";
  remoteFilter: RemoteFilter;
  sort: { key: SortKey; dir: "asc" | "desc" };
  exportStatus: string;

  loadLeads: () => Promise<void>;
  setQuery: (query: string) => void;
  setStatusFilter: (status: LeadStatus | "All") => void;
  setRemoteFilter: (filter: RemoteFilter) => void;
  toggleSort: (key: SortKey) => void;
  clearFiltersAndSort: () => void;
  moveLead: (id: number, status: LeadStatus) => Promise<void>;
  exportLeads: (leads: Lead[]) => Promise<void>;
  filteredLeads: () => Lead[];
}

const DEFAULT_SORT: { key: SortKey; dir: "asc" | "desc" } = { key: "date_posted", dir: "desc" };

export const useLeadsStore = create<LeadsState>((set, get) => ({
  leads: [],
  loading: true,
  error: "",

  query: "",
  statusFilter: "All",
  remoteFilter: "all",
  sort: DEFAULT_SORT,
  exportStatus: "",

  loadLeads: async () => {
    set({ loading: true, error: "" });
    try {
      const leads = await window.electronAPI.getLeads();
      set({ leads, loading: false });
    } catch (err) {
      set({ loading: false, error: err instanceof Error ? err.message : String(err) });
    }
  },

  setQuery: (query) => set({ query }),
  setStatusFilter: (statusFilter) => set({ statusFilter }),
  setRemoteFilter: (remoteFilter) => set({ remoteFilter }),

  toggleSort: (key) =>
    set((state) => ({
      sort: state.sort.key === key ? { key, dir: state.sort.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" },
    })),

  clearFiltersAndSort: () =>
    set({ query: "", statusFilter: "All", remoteFilter: "all", sort: DEFAULT_SORT }),

  moveLead: async (id, status) => {
    set((state) => ({
      leads: state.leads.map((l) => (l.id === id ? { ...l, status } : l)),
    }));
    await window.electronAPI.updateLeadStatus(id, status);
  },

  exportLeads: async (leads) => {
    const result = await window.electronAPI.exportLeads(leads);
    if (result.ok) {
      set({ exportStatus: `Saved to ${result.filePath}` });
    } else if (!result.canceled) {
      set({ exportStatus: result.error || "Export failed." });
    }
    setTimeout(() => set({ exportStatus: "" }), 4000);
  },

  filteredLeads: () => {
    const { leads, query, statusFilter, remoteFilter, sort } = get();
    const q = query.trim().toLowerCase();

    const out = leads.filter((l) => {
      const matchesQuery =
        !q ||
        l.company_name.toLowerCase().includes(q) ||
        l.job_title.toLowerCase().includes(q) ||
        (l.location ?? "").toLowerCase().includes(q);
      const matchesStatus = statusFilter === "All" || l.status === statusFilter;
      const matchesRemote =
        remoteFilter === "all" ||
        (remoteFilter === "remote" && l.remote_only) ||
        (remoteFilter === "onsite" && !l.remote_only);
      return matchesQuery && matchesStatus && matchesRemote;
    });

    out.sort((a, b) => {
      const dir = sort.dir === "asc" ? 1 : -1;
      if (sort.key === "date_posted") {
        const at = a.date_posted ? new Date(a.date_posted).getTime() : 0;
        const bt = b.date_posted ? new Date(b.date_posted).getTime() : 0;
        return dir * (at - bt);
      }
      const av = String(a[sort.key] ?? "");
      const bv = String(b[sort.key] ?? "");
      return dir * av.localeCompare(bv);
    });

    return out;
  },
}));
