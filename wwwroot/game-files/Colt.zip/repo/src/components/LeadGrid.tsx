import type { Lead } from "../../modules/leads/types/job";
import { LeadBox } from "./LeadBox";

interface LeadGridProps {
  leads: Lead[];
  onOpenNotes: (lead: Lead) => void;
  onOpenOutreach: (lead: Lead) => void;
}

export function LeadGrid({ leads, onOpenNotes, onOpenOutreach }: LeadGridProps) {
  if (leads.length === 0) {
    return <p className="empty-state">No leads match these filters. Try clearing filters and sort.</p>;
  }

  return (
    <div className="lead-grid">
      {leads.map((lead) => (
        <LeadBox key={lead.id} lead={lead} onOpenNotes={onOpenNotes} onOpenOutreach={onOpenOutreach} />
      ))}
    </div>
  );
}
