import type { LeadStatus } from "../../modules/leads/types/job";

export const STAGES: LeadStatus[] = ["New", "Contacted", "Replied", "Qualified", "Won", "Lost"];

const TINTS: Record<LeadStatus, { tint: string; ink: string }> = {
  New: { tint: "#F7ECD9", ink: "#8A5A16" },
  Contacted: { tint: "#E6ECF5", ink: "#3D5D8A" },
  Replied: { tint: "#E1EFEC", ink: "#2F6F63" },
  Qualified: { tint: "#D9E6DE", ink: "#1F4E3F" },
  Won: { tint: "#E3EEDF", ink: "#2F6B2A" },
  Lost: { tint: "#F3E2DC", ink: "#A6432D" },
};

export function stageMeta(key: LeadStatus) {
  return TINTS[key] ?? TINTS.New;
}

export function StageBadge({ status }: { status: LeadStatus }) {
  const m = stageMeta(status);
  return (
    <span className="stage-badge" style={{ backgroundColor: m.tint, color: m.ink }}>
      {status}
    </span>
  );
}
