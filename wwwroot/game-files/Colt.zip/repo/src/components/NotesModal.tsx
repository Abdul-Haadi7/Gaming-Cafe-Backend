import { useEffect, useState } from "react";
import { X, Loader2, Check } from "lucide-react";
import type { Lead } from "../../modules/leads/types/job";

interface NotesModalProps {
  lead: Lead;
  onClose: () => void;
}

export function NotesModal({ lead, onClose }: NotesModalProps) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [isNew, setIsNew] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function fetchNote() {
      setLoading(true);
      setError("");
      try {
        const result = await window.electronAPI.getNote(lead.id);
        if (cancelled) return;
        if (result.note) {
          setText(result.note.note);
          setIsNew(false);
        } else {
          setText("");
          setIsNew(true);
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : String(err));
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    fetchNote();
    return () => {
      cancelled = true;
    };
  }, [lead.id]);

  async function save() {
    setSaving(true);
    setError("");
    try {
      await window.electronAPI.saveNote(lead.id, text);
      setIsNew(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal__header">
          <div>
            <h3 className="modal__title">{isNew ? "Add note" : "Edit note"}</h3>
            <p className="modal__subtitle">{lead.company_name}</p>
          </div>
          <button onClick={onClose} className="icon-button" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="modal__body">
          {loading ? (
            <div className="loading-row">
              <Loader2 size={16} className="spin" /> Loading note…
            </div>
          ) : (
            <>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={6}
                placeholder="Log a call, an objection, or a next step…"
                className="textarea"
                autoFocus
              />
              {error && <p className="error-text">{error}</p>}
            </>
          )}
        </div>

        <div className="modal__footer">
          <button onClick={onClose} className="secondary-button">
            Close
          </button>
          <button onClick={save} disabled={loading || saving} className="primary-button button-row__push-right">
            {saving ? (
              <Loader2 size={14} className="spin" />
            ) : saved ? (
              <Check size={14} />
            ) : null}
            {saved ? "Saved" : isNew ? "Add note" : "Save changes"}
          </button>
        </div>
      </div>
    </div>
  );
}
