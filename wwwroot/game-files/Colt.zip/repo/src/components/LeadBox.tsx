import { StickyNote, Send, MapPin, ExternalLink, Globe, Building2 } from "lucide-react";
import type { Lead } from "../../modules/leads/types/job";
import { StageBadge } from "./StageBadge";
import { formatDate, daysAgo } from "../utils/format";

interface LeadBoxProps {
  lead: Lead;
  onOpenNotes: (lead: Lead) => void;
  onOpenOutreach: (lead: Lead) => void;
}

export function LeadBox({ lead, onOpenNotes, onOpenOutreach }: LeadBoxProps) {
  return (
    <div className="lead-box">
      <div className="lead-box__header">
        <div>
          <p className="lead-box__company">
            <Building2 size={14} /> {lead.company_name}
          </p>
          <p className="lead-box__title">{lead.job_title}</p>
        </div>
        <StageBadge status={lead.status} />
      </div>

      <div className="lead-box__meta">
        <span>
          <MapPin size={12} /> {lead.location ?? "Unknown"}
        </span>
        {lead.remote_only && (
          <span className="lead-box__remote">
            <Globe size={12} /> Remote
          </span>
        )}
      </div>

      <div className="lead-box__meta">
        <span>{formatDate(lead.date_posted)}</span>
        <span className="muted-text">· {daysAgo(lead.date_posted)}</span>
      </div>

      <a href={lead.job_url} target="_blank" rel="noreferrer" className="lead-box__link">
        View posting <ExternalLink size={11} />
      </a>

      <div className="lead-box__footer">
        <button className="secondary-button" onClick={() => onOpenNotes(lead)}>
          <StickyNote size={13} /> Edit notes
        </button>
        <button className="secondary-button" onClick={() => onOpenOutreach(lead)}>
          <Send size={13} /> Generate outreach
        </button>
      </div>
    </div>
  );
}
