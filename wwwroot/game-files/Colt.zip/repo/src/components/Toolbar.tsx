import { Search, Download, ArrowUpDown, RotateCcw } from "lucide-react";
import { STAGES } from "./StageBadge";
import type { LeadStatus } from "../../modules/leads/types/job";
import type { RemoteFilter, SortKey } from "../store/useLeadsStore";

interface ToolbarProps {
  query: string;
  setQuery: (q: string) => void;
  statusFilter: LeadStatus | "All";
  setStatusFilter: (s: LeadStatus | "All") => void;
  remoteFilter: RemoteFilter;
  setRemoteFilter: (r: RemoteFilter) => void;
  sort: { key: SortKey; dir: "asc" | "desc" };
  toggleSort: (key: SortKey) => void;
  onClear: () => void;
  onExport: () => void;
}

const SORT_OPTIONS: Array<[SortKey, string]> = [
  ["date_posted", "Date posted"],
  ["company_name", "Company"],
  ["location", "Location"],
  ["status", "Status"],
];

export function Toolbar({
  query,
  setQuery,
  statusFilter,
  setStatusFilter,
  remoteFilter,
  setRemoteFilter,
  sort,
  toggleSort,
  onClear,
  onExport,
}: ToolbarProps) {
  return (
    <div className="toolbar">
      <div className="toolbar__title">
        <h1>Signal Desk</h1>
        <p>Job postings matching your buyer signal, tracked from first sighting to close.</p>
      </div>

      <div className="search-box">
        <Search size={14} />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search company, title, location" />
      </div>

      <select
        value={statusFilter}
        onChange={(e) => setStatusFilter(e.target.value as LeadStatus | "All")}
        className="select-input"
      >
        <option value="All">All statuses</option>
        {STAGES.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>

      <select
        value={remoteFilter}
        onChange={(e) => setRemoteFilter(e.target.value as RemoteFilter)}
        className="select-input"
      >
        <option value="all">Remote + on-site</option>
        <option value="remote">Remote only</option>
        <option value="onsite">On-site only</option>
      </select>

      <select value={sort.key} onChange={(e) => toggleSort(e.target.value as SortKey)} className="select-input">
        {SORT_OPTIONS.map(([key, label]) => (
          <option key={key} value={key}>
            Sort: {label} {sort.key === key ? (sort.dir === "asc" ? "↑" : "↓") : ""}
          </option>
        ))}
      </select>
      <button className="icon-button" onClick={() => toggleSort(sort.key)} aria-label="Flip sort direction">
        <ArrowUpDown size={16} />
      </button>

      <button className="secondary-button" onClick={onClear}>
        <RotateCcw size={13} /> Clear
      </button>

      <button className="primary-button" onClick={onExport}>
        <Download size={14} /> Export CSV
      </button>
    </div>
  );
}
