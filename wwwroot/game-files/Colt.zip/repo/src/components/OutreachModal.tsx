import { useState } from "react";
import { X, Send, Loader2, Copy, Check } from "lucide-react";
import type { Lead } from "../../modules/leads/types/job";

interface OutreachModalProps {
  lead: Lead;
  onClose: () => void;
}

export function OutreachModal({ lead, onClose }: OutreachModalProps) {
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  async function generate() {
    setLoading(true);
    setError("");
    try {
      const result = await window.electronAPI.generateOutreach(lead);
      if (!result.ok) {
        setError(result.error || "Couldn't generate a draft just now.");
      } else {
        setDraft(result.text ?? "");
      }
    } catch (e) {
      setError("Couldn't reach the app's backend. Is the main process running?");
    } finally {
      setLoading(false);
    }
  }

  function copyToClipboard() {
    navigator.clipboard.writeText(draft);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="modal-overlay">
      <div className="modal modal--wide">
        <div className="modal__header">
          <div>
            <h3 className="modal__title">Outreach message</h3>
            <p className="modal__subtitle">
              {lead.company_name} · {lead.job_title}
            </p>
          </div>
          <button onClick={onClose} className="icon-button" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="modal__body">
          {!draft && !loading && (
            <button onClick={generate} className="primary-button primary-button--full">
              <Send size={15} /> Generate outreach message
            </button>
          )}

          {loading && (
            <div className="loading-row">
              <Loader2 size={16} className="spin" /> Drafting message…
            </div>
          )}

          {error && <p className="error-text">{error}</p>}

          {draft && !loading && (
            <>
              <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={7} className="textarea" />
              <div className="button-row">
                <button onClick={generate} className="secondary-button">
                  Regenerate
                </button>
                <button onClick={copyToClipboard} className="secondary-button button-row__push-right">
                  {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Copied" : "Copy"}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
