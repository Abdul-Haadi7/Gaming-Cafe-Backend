// Supabase-backed persistence for Module C. Runs in the main process only —
// the Supabase key never reaches the sandboxed renderer. Person 2's
// connector/normalizer pipeline writes into `leads` directly (via its own
// Supabase calls, or via a shared insert helper you add here); this file is
// specifically what the UI (Person 3) reads and writes through IPC.

import { createClient, SupabaseClient } from "@supabase/supabase-js";
import type { Lead, LeadNote, LeadStatus } from "../types/job";

let client: SupabaseClient | null = null;

export function initSupabase(): void {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_KEY;
  if (!url || !key) {
    throw new Error(
      "Missing SUPABASE_URL or SUPABASE_KEY. Add them to your .env file (see .env.example)."
    );
  }
  client = createClient(url, key);
}

function getClient(): SupabaseClient {
  if (!client) throw new Error("Supabase not initialized — call initSupabase() first.");
  return client;
}

export async function getAllLeads(): Promise<Lead[]> {
  const { data, error } = await getClient()
    .from("leads")
    .select("*")
    .order("date_posted", { ascending: false });
  if (error) throw new Error(`Failed to fetch leads: ${error.message}`);
  return data as Lead[];
}

export async function updateLeadStatus(id: number, status: LeadStatus): Promise<void> {
  const { error } = await getClient()
    .from("leads")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", id);
  if (error) throw new Error(`Failed to update lead status: ${error.message}`);
}

// Fetch-or-none: the UI treats a lead as having at most one note.
export async function getNoteForLead(leadId: number): Promise<LeadNote | null> {
  const { data, error } = await getClient()
    .from("lead_notes")
    .select("*")
    .eq("lead_id", leadId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw new Error(`Failed to fetch note: ${error.message}`);
  return (data as LeadNote) ?? null;
}

// Upsert-by-lead: updates the existing note if one exists for this lead,
// otherwise inserts a new row.
export async function saveNoteForLead(leadId: number, text: string): Promise<LeadNote> {
  const existing = await getNoteForLead(leadId);
  const now = new Date().toISOString();

  if (existing) {
    const { data, error } = await getClient()
      .from("lead_notes")
      .update({ note: text, updated_at: now })
      .eq("id", existing.id)
      .select()
      .single();
    if (error) throw new Error(`Failed to update note: ${error.message}`);
    return data as LeadNote;
  }

  const { data, error } = await getClient()
    .from("lead_notes")
    .insert({ lead_id: leadId, note: text, updated_at: now })
    .select()
    .single();
  if (error) throw new Error(`Failed to create note: ${error.message}`);
  return data as LeadNote;
}
