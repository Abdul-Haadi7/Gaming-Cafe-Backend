// Shared contract for Module C, matching the live Supabase schema.
// `leads` and `lead_notes` are the two tables actually provisioned;
// field names below mirror the DB columns 1:1 (snake_case, as Postgres
// returns them) rather than being renamed for the frontend, so there is
// exactly one shape to keep in sync with the database.

export type LeadStatus =
  | "New"
  | "Contacted"
  | "Replied"
  | "Qualified"
  | "Won"
  | "Lost";

// One row in `leads`.
export interface Lead {
  id: number;
  created_at: string;
  raw_job_id: number | null;
  source_id: number | null;
  external_job_id: string | null;
  company_name: string;
  company_domain: string | null;
  job_title: string;
  job_url: string;
  location: string | null;
  date_posted: string | null; // timestamp
  description: string | null;
  industry: string | null;
  remote_only: boolean;
  employment_type: string | null;
  deduplication_key: string | null;
  status: LeadStatus;
  updated_at: string;
}

// One row in `lead_notes`. In practice the UI treats this as at most one
// note per lead (fetch-or-create-then-edit), even though the table doesn't
// enforce a uniqueness constraint on lead_id.
export interface LeadNote {
  id: number;
  created_at: string;
  lead_id: number;
  note: string;
  updated_at: string;
}
